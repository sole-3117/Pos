import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// DEV_AUTH=true bo'lganda authMiddleware shu ID'lardan foydalanadi.
// Ular bazada bo'lmasa, buyurtma yaratishda "Foreign key constraint failed" xatosi chiqadi.
const TENANT_ID = 'default-tenant';

async function main() {
  await prisma.tenant.upsert({
    where: { id: TENANT_ID },
    update: {},
    create: { id: TENANT_ID, name: 'Asosiy do\'kon' }
  });

  await prisma.user.upsert({
    where: { id: 'cashier-1' },
    update: {},
    create: { id: 'cashier-1', tenantId: TENANT_ID, name: 'Kassir', role: 'CASHIER' }
  });

  await prisma.user.upsert({
    where: { id: 'admin-1' },
    update: {},
    create: { id: 'admin-1', tenantId: TENANT_ID, name: 'Admin', role: 'ADMIN' }
  });

  const products = [
    { sku: 'OLMA-001', name: 'Olma Golden (1 kg)', price: 15000, stock: 50 },
    { sku: 'NON-001', name: 'Non', price: 4000, stock: 100 },
    { sku: 'SUT-001', name: 'Sut 1 l', price: 12000, stock: 30 }
  ];

  for (const p of products) {
    await prisma.product.upsert({
      where: { tenantId_sku: { tenantId: TENANT_ID, sku: p.sku } },
      update: {},
      create: {
        tenantId: TENANT_ID,
        sku: p.sku,
        name: p.name,
        price: p.price,
        stock: p.stock
      }
    });
  }

  console.log('Seed tugadi: default-tenant, cashier-1, admin-1 va 3 ta mahsulot yaratildi.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());

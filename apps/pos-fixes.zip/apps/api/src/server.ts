import 'dotenv/config';
import express from 'express';
import orderRoutes from './routes/orderRoutes';
import { PrismaClient } from '@prisma/client';
import { requireAuth, requireRole, isDevAuthEnabled, AuthenticatedRequest } from './middlewares/authMiddleware';
import { getAuthSecret } from './utils/token';
import './orderBot'; // Telegram botni ishga tushiradi (TELEGRAM_BOT_TOKEN, BOT_HMAC_SECRET, MAIN_ADMIN sozlangan bo'lsa)

if (isDevAuthEnabled()) {
  console.warn('DIQQAT: DEV_AUTH yoqilgan — tokensiz so\'rovlar dev foydalanuvchi sifatida qabul qilinadi. Productionda ishlatmang!');
} else {
  getAuthSecret(); // AUTH_SECRET yo'q yoki qisqa bo'lsa, server ishga tushmaydi
}

const prisma = new PrismaClient();
const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/api/products', requireAuth, requireRole(['ADMIN', 'CASHIER']), async (req, res) => {
  try {
    const { tenantId } = (req as AuthenticatedRequest).user!;
    const products = await prisma.product.findMany({
      where: { tenantId },
      orderBy: { name: 'asc' }
    });
    res.json(products);
  } catch (err: any) {
    console.error('Mahsulotlarni olishda xatolik:', err);
    res.status(500).json({ error: 'Serverda ichki xatolik yuz berdi' });
  }
});

app.use('/api/orders', orderRoutes);

app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Server xatoligi:', err);
  res.status(500).json({ error: 'Serverda ichki xatolik yuz berdi' });
});

app.listen(PORT, () => {
  console.log(`🚀 POS API serveri http://localhost:${PORT} portida ishga tushdi`);
});

export default app;

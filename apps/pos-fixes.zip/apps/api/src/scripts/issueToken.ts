import 'dotenv/config';
import { signToken } from '../utils/token';

// Ishlatish: npm run token -- <userId> <tenantId> [ADMIN|CASHIER] [soat]
const [id, tenantId, role = 'CASHIER', hours = '12'] = process.argv.slice(2);

if (!id || !tenantId || (role !== 'ADMIN' && role !== 'CASHIER') || !(Number(hours) > 0)) {
  console.error('Ishlatish: npm run token -- <userId> <tenantId> [ADMIN|CASHIER] [soat]');
  process.exit(1);
}

console.log(signToken({ id, tenantId, role }, Number(hours) * 60 * 60));

import crypto from 'crypto';

export type Role = 'ADMIN' | 'CASHIER';

export interface TokenPayload {
  id: string;
  tenantId: string;
  role: Role;
  name?: string;
  /** Amal qilish muddati (unix sekundlarda) */
  exp: number;
}

const MIN_SECRET_LENGTH = 32;

export function getAuthSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < MIN_SECRET_LENGTH) {
    throw new Error(
      `AUTH_SECRET o'rnatilmagan yoki juda qisqa (kamida ${MIN_SECRET_LENGTH} belgi kerak)`
    );
  }
  return secret;
}

function sign(body: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(body).digest('base64url');
}

/**
 * Imzolangan token yaratadi: base64url(payload).base64url(hmac)
 * Tokenni faqat AUTH_SECRET'ni biladigan tomon yarata oladi.
 */
export function signToken(
  payload: Omit<TokenPayload, 'exp'>,
  ttlSeconds = 12 * 60 * 60,
  secret: string = getAuthSecret()
): string {
  const full: TokenPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds
  };
  const body = Buffer.from(JSON.stringify(full)).toString('base64url');
  return `${body}.${sign(body, secret)}`;
}

/**
 * Tokenni tekshiradi. Imzo noto'g'ri, muddat o'tgan yoki format buzilgan bo'lsa null qaytaradi.
 */
export function verifyToken(token: string, secret: string = getAuthSecret()): TokenPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;

  const [body, signature] = parts;
  const given = Buffer.from(signature);
  const expected = Buffer.from(sign(body, secret));
  if (given.length !== expected.length || !crypto.timingSafeEqual(given, expected)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (typeof payload.id !== 'string' || !payload.id) return null;
    if (typeof payload.tenantId !== 'string' || !payload.tenantId) return null;
    if (payload.role !== 'ADMIN' && payload.role !== 'CASHIER') return null;
    if (typeof payload.exp !== 'number' || payload.exp < Date.now() / 1000) return null;
    return payload as TokenPayload;
  } catch {
    return null;
  }
}

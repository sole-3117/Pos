import { Request, Response } from 'express';
import { requireAuth, requireRole } from './authMiddleware';
import { signToken, verifyToken } from '../utils/token';

const SECRET = 'test-secret-test-secret-test-secret-1234';

function mockReq(headers: Record<string, string> = {}): Request {
  return { headers } as unknown as Request;
}

function mockRes() {
  const res: any = { statusCode: 200, body: undefined };
  res.status = (code: number) => {
    res.statusCode = code;
    return res;
  };
  res.json = (body: unknown) => {
    res.body = body;
    return res;
  };
  return res as Response & { statusCode: number; body: any };
}

function run(headers: Record<string, string>) {
  const req = mockReq(headers);
  const res = mockRes();
  let called = false;
  requireAuth(req, res, () => {
    called = true;
  });
  return { req: req as any, res, called };
}

describe('requireAuth', () => {
  const OLD_ENV = process.env;

  beforeEach(() => {
    process.env = { ...OLD_ENV, AUTH_SECRET: SECRET, NODE_ENV: 'test' };
    delete process.env.DEV_AUTH;
  });

  afterAll(() => {
    process.env = OLD_ENV;
  });

  test('to\'g\'ri imzolangan Bearer token qabul qilinadi', () => {
    const token = signToken({ id: 'u1', tenantId: 't1', role: 'CASHIER' });
    const { req, called } = run({ authorization: `Bearer ${token}` });
    expect(called).toBe(true);
    expect(req.user).toMatchObject({ id: 'u1', tenantId: 't1', role: 'CASHIER' });
  });

  test('pos_token cookie orqali kirish ishlaydi', () => {
    const token = signToken({ id: 'u1', tenantId: 't1', role: 'ADMIN' });
    const { req, called } = run({ cookie: `a=b; pos_token=${token}; c=d` });
    expect(called).toBe(true);
    expect(req.user.role).toBe('ADMIN');
  });

  test('x-user-id / x-tenant-id / x-role header\'lari bilan soxtalashtirib bo\'lmaydi', () => {
    const { res, called } = run({ 'x-user-id': 'hacker', 'x-tenant-id': 'victim', 'x-role': 'ADMIN' });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(401);
  });

  test('imzosiz base64 JSON token rad etiladi', () => {
    const fake = Buffer.from(JSON.stringify({ id: 'x', tenantId: 'victim', role: 'ADMIN' })).toString('base64');
    const { res, called } = run({ authorization: `Bearer ${fake}` });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(401);
  });

  test('oddiy matnli Bearer token endi ADMIN bermaydi', () => {
    const { res, called } = run({ authorization: 'Bearer anything' });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(401);
  });

  test('payload o\'zgartirilgan token (rolni ADMIN qilish) rad etiladi', () => {
    const token = signToken({ id: 'u1', tenantId: 't1', role: 'CASHIER' });
    const [, sig] = token.split('.');
    const forgedBody = Buffer.from(
      JSON.stringify({ id: 'u1', tenantId: 't1', role: 'ADMIN', exp: 9999999999 })
    ).toString('base64url');
    const { called, res } = run({ authorization: `Bearer ${forgedBody}.${sig}` });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(401);
  });

  test('muddati o\'tgan token rad etiladi', () => {
    const token = signToken({ id: 'u1', tenantId: 't1', role: 'CASHIER' }, -10);
    expect(verifyToken(token)).toBeNull();
    const { called } = run({ authorization: `Bearer ${token}` });
    expect(called).toBe(false);
  });

  test('boshqa kalit bilan imzolangan token rad etiladi', () => {
    const token = signToken({ id: 'u1', tenantId: 't1', role: 'CASHIER' }, 3600, 'another-secret-another-secret-123456');
    const { called } = run({ authorization: `Bearer ${token}` });
    expect(called).toBe(false);
  });

  test('token ham, DEV_AUTH ham bo\'lmasa 401', () => {
    const { res, called } = run({ cookie: 'session=abc' });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(401);
  });

  test('DEV_AUTH faqat production bo\'lmaganda ishlaydi', () => {
    process.env.DEV_AUTH = 'true';
    expect(run({}).called).toBe(true);

    process.env.NODE_ENV = 'production';
    expect(run({}).called).toBe(false);
  });

  test('DEV_AUTH yoqilgan bo\'lsa ham yaroqsiz token rad etiladi', () => {
    process.env.DEV_AUTH = 'true';
    const { called } = run({ authorization: 'Bearer garbage' });
    expect(called).toBe(false);
  });
});

describe('requireRole', () => {
  test('ruxsat etilmagan rolga 403 qaytaradi', () => {
    const req = { user: { id: 'u', tenantId: 't', role: 'CASHIER' } } as any;
    const res = mockRes();
    let called = false;
    requireRole(['ADMIN'])(req, res, () => {
      called = true;
    });
    expect(called).toBe(false);
    expect(res.statusCode).toBe(403);
  });
});

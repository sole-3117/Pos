import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../utils/token';

export interface AuthenticatedUser {
  id: string;
  tenantId: string;
  role: 'ADMIN' | 'CASHIER';
  name?: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthenticatedUser;
}

const COOKIE_NAME = 'pos_token';

/**
 * Faqat lokal ishlab chiqish uchun: DEV_AUTH=true bo'lsa va NODE_ENV=production bo'lmasa,
 * tokensiz so'rovlar DEV_* o'zgaruvchilaridagi foydalanuvchi sifatida qabul qilinadi.
 */
export const isDevAuthEnabled = () =>
  process.env.NODE_ENV !== 'production' && process.env.DEV_AUTH === 'true';

function readToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim() || null;
  }

  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    for (const part of cookieHeader.split(';')) {
      const idx = part.indexOf('=');
      if (idx === -1) continue;
      if (part.slice(0, idx).trim() === COOKIE_NAME) {
        return part.slice(idx + 1).trim() || null;
      }
    }
  }

  return null;
}

/**
 * Autentifikatsiya middleware:
 * Foydalanuvchi ma'lumotlari FAQAT imzolangan tokendan olinadi (Authorization: Bearer ... yoki pos_token cookie).
 * Mijoz yuboradigan x-user-id / x-tenant-id / x-role kabi header'larga ishonilmaydi.
 */
export const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const customReq = req as AuthenticatedRequest;
  const token = readToken(req);

  if (token) {
    let payload = null;
    try {
      payload = verifyToken(token);
    } catch (err) {
      console.error('Token tekshirishda xatolik (AUTH_SECRET sozlamasini tekshiring):', err);
    }

    if (!payload) {
      return res.status(401).json({ error: 'Avtorizatsiyadan o\'tilmagan: token yaroqsiz yoki muddati o\'tgan' });
    }

    customReq.user = {
      id: payload.id,
      tenantId: payload.tenantId,
      role: payload.role,
      name: payload.name
    };
    return next();
  }

  if (isDevAuthEnabled()) {
    customReq.user = {
      id: process.env.DEV_USER_ID || 'cashier-1',
      tenantId: process.env.DEV_TENANT_ID || 'default-tenant',
      role: process.env.DEV_ROLE === 'ADMIN' ? 'ADMIN' : 'CASHIER',
      name: 'Dev foydalanuvchi'
    };
    return next();
  }

  return res.status(401).json({ error: 'Avtorizatsiyadan o\'tilmagan: token topilmadi' });
};

/**
 * Rolga asoslangan ruxsat berish (RBAC) middleware:
 * Berilgan rollardan biri mavjudligini tekshiradi
 */
export const requireRole = (allowedRoles: Array<'ADMIN' | 'CASHIER'>) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const customReq = req as AuthenticatedRequest;

    if (!customReq.user) {
      return res.status(401).json({ error: 'Foydalanuvchi ma\'lumotlari topilmadi' });
    }

    if (!allowedRoles.includes(customReq.user.role)) {
      return res.status(403).json({
        error: `Ruxsat etilmagan: Ushbu amal uchun quyidagi rollardan biri talab qilinadi: ${allowedRoles.join(', ')}`
      });
    }

    next();
  };
};
